package pack.rent.model;

public class RentDto {
	private String R_no, g_id, C_name, C_jong, C_bun, C_daeil, C_banil, C_color, C_price, C_image, C_place;



	public String getR_no() {
		return R_no;
	}

	public void setR_no(String r_no) {
		R_no = r_no;
	}

	public String getG_id() {
		return g_id;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	public String getC_name() {
		return C_name;
	}

	public void setC_name(String c_name) {
		C_name = c_name;
	}

	public String getC_jong() {
		return C_jong;
	}

	public void setC_jong(String c_jong) {
		C_jong = c_jong;
	}

	public String getC_bun() {
		return C_bun;
	}

	public void setC_bun(String c_bun) {
		C_bun = c_bun;
	}

	public String getC_daeil() {
		return C_daeil;
	}

	public void setC_daeil(String c_daeil) {
		C_daeil = c_daeil;
	}

	public String getC_banil() {
		return C_banil;
	}

	public void setC_banil(String c_banil) {
		C_banil = c_banil;
	}

	public String getC_color() {
		return C_color;
	}

	public void setC_color(String c_color) {
		C_color = c_color;
	}

	public String getC_price() {
		return C_price;
	}

	public void setC_price(String c_price) {
		C_price = c_price;
	}

	public String getC_image() {
		return C_image;
	}

	public void setC_image(String c_image) {
		C_image = c_image;
	}

	public String getC_place() {
		return C_place;
	}

	public void setC_place(String c_place) {
		C_place = c_place;
	}
	
	
}
