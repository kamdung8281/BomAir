package pack.model;

public class BookDto {
	private String t_no, g_id, air_name, ab_date, pay, s_no, O_sdate, O_price, O_soyo, O_stime, hap;

	public String getHap() {
		return hap;
	}

	public void setHap(String hap) {
		this.hap = hap;
	}

	public String getO_sdate() {
		return O_sdate;
	}

	public void setO_sdate(String o_sdate) {
		O_sdate = o_sdate;
	}

	public String getO_price() {
		return O_price;
	}

	public void setO_price(String o_price) {
		O_price = o_price;
	}

	public String getO_soyo() {
		return O_soyo;
	}

	public void setO_soyo(String o_soyo) {
		O_soyo = o_soyo;
	}

	public String getO_stime() {
		return O_stime;
	}

	public void setO_stime(String o_stime) {
		O_stime = o_stime;
	}

	public String getT_no() {
		return t_no;
	}

	public void setT_no(String t_no) {
		this.t_no = t_no;
	}

	public String getG_id() {
		return g_id;
	}

	public String getS_no() {
		return s_no;
	}

	public void setS_no(String s_no) {
		this.s_no = s_no;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	public String getAir_name() {
		return air_name;
	}

	public void setAir_name(String air_name) {
		this.air_name = air_name;
	}

	public String getAb_date() {
		return ab_date;
	}

	public void setAb_date(String ab_date) {
		this.ab_date = ab_date;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}



}
