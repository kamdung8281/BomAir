package pack.controller;

public class CompleteBean {
	private String people,
	l_code, o_sdate,
	pay, start, end, time, a_name, grade,
	o_sdate_R,
	start_R, end_R, time_R, a_name_R, grade_R,
	t_no, maxT, maxT_R, g_id;

	public String getPeople() {
		return people;
	}

	public void setPeople(String people) {
		this.people = people;
	}

	public String getL_code() {
		return l_code;
	}

	public void setL_code(String l_code) {
		this.l_code = l_code;
	}

	public String getO_sdate() {
		return o_sdate;
	}

	public void setO_sdate(String o_sdate) {
		this.o_sdate = o_sdate;
	}

	public String getPay() {
		return pay;
	}

	public void setPay(String pay) {
		this.pay = pay;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}

	public String getEnd() {
		return end;
	}

	public void setEnd(String end) {
		this.end = end;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getA_name() {
		return a_name;
	}

	public void setA_name(String a_name) {
		this.a_name = a_name;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getMaxT_R() {
		return maxT_R;
	}

	public void setMaxT_R(String maxT_R) {
		this.maxT_R = maxT_R;
	}

	public String getO_sdate_R() {
		return o_sdate_R;
	}

	public void setO_sdate_R(String o_sdate_R) {
		this.o_sdate_R = o_sdate_R;
	}

	public String getStart_R() {
		return start_R;
	}

	public void setStart_R(String start_R) {
		this.start_R = start_R;
	}

	public String getEnd_R() {
		return end_R;
	}

	public void setEnd_R(String end_R) {
		this.end_R = end_R;
	}

	public String getTime_R() {
		return time_R;
	}

	public void setTime_R(String time_R) {
		this.time_R = time_R;
	}

	public String getA_name_R() {
		return a_name_R;
	}

	public void setA_name_R(String a_name_R) {
		this.a_name_R = a_name_R;
	}

	public String getGrade_R() {
		return grade_R;
	}

	public void setGrade_R(String grade_R) {
		this.grade_R = grade_R;
	}

	public String getT_no() {
		return t_no;
	}

	public void setT_no(String t_no) {
		this.t_no = t_no;
	}

	public String getMaxT() {
		return maxT;
	}

	public void setMaxT(String maxT) {
		this.maxT = maxT;
	}

	public String getG_id() {
		return g_id;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	
}
