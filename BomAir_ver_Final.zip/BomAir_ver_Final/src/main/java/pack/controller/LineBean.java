package pack.controller;

public class LineBean {
	private String l_code, air_name, o_sdate, o_price, o_soyo, o_stime, o_sdate_R;
	private int people;

	public int getPeople() {
		return people;
	}

	public void setPeople(int people) {
		this.people = people;
	}

	public String getL_code() {
		return l_code;
	}

	public String getO_sdate_R() {
		return o_sdate_R;
	}

	public void setO_sdate_R(String o_sdate_R) {
		this.o_sdate_R = o_sdate_R;
	}

	public void setL_code(String l_code) {
		this.l_code = l_code;
	}

	public String getAir_name() {
		return air_name;
	}

	public void setAir_name(String air_name) {
		this.air_name = air_name;
	}

	public String getO_sdate() {
		return o_sdate;
	}

	public void setO_sdate(String o_sdate) {
		this.o_sdate = o_sdate;
	}

	public String getO_price() {
		return o_price;
	}

	public void setO_price(String o_price) {
		this.o_price = o_price;
	}

	public String getO_soyo() {
		return o_soyo;
	}

	public void setO_soyo(String o_soyo) {
		this.o_soyo = o_soyo;
	}

	public String getO_stime() {
		return o_stime;
	}

	public void setO_stime(String o_stime) {
		this.o_stime = o_stime;
	}


}
