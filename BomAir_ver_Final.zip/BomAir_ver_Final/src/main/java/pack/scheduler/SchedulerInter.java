package pack.scheduler;

import java.util.List;

public interface SchedulerInter {
	public boolean DailyDelete(String tname);
	public boolean DailyDelete2(String tname);
	
//	public int CreateTables();
//	public int insertintoTables();
}