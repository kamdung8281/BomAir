package pack.guest.controller;

public class GuestBean {
	
	private String g_id, g_pwd,	g_name,	g_birth, g_pp, g_addr, g_tel, g_mail;

	public String getG_id() {
		return g_id;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	public String getG_pwd() {
		return g_pwd;
	}

	public void setG_pwd(String g_pwd) {
		this.g_pwd = g_pwd;
	}

	public String getG_name() {
		return g_name;
	}

	public void setG_name(String g_name) {
		this.g_name = g_name;
	}

	public String getG_birth() {
		return g_birth;
	}

	public void setG_birth(String g_birth) {
		this.g_birth = g_birth;
	}

	public String getG_pp() {
		return g_pp;
	}

	public void setG_pp(String g_pp) {
		this.g_pp = g_pp;
	}

	public String getG_addr() {
		return g_addr;
	}

	public void setG_addr(String g_addr) {
		this.g_addr = g_addr;
	}

	public String getG_tel() {
		return g_tel;
	}

	public void setG_tel(String g_tel) {
		this.g_tel = g_tel;
	}

	public String getG_mail() {
		return g_mail;
	}

	public void setG_mail(String g_mail) {
		this.g_mail = g_mail;
	}
}
