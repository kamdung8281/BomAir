package pack.mainpage.model;

public class ReservationDto {
	private String  l_end, l_start, o_sdate, o_price, o_soyo, o_stime;

	public String getL_end() {
		return l_end;
	}

	public void setL_end(String l_end) {
		this.l_end = l_end;
	}

	public String getL_start() {
		return l_start;
	}

	public void setL_start(String l_start) {
		this.l_start = l_start;
	}

	public String getO_sdate() {
		return o_sdate;
	}

	public void setO_sdate(String o_sdate) {
		this.o_sdate = o_sdate;
	}

	public String getO_price() {
		return o_price;
	}

	public void setO_price(String o_price) {
		this.o_price = o_price;
	}

	public String getO_soyo() {
		return o_soyo;
	}

	public void setO_soyo(String o_soyo) {
		this.o_soyo = o_soyo;
	}

	public String getO_stime() {
		return o_stime;
	}

	public void setO_stime(String o_stime) {
		this.o_stime = o_stime;
	}
	
	
}
