package pack.mainpage.model;

public class CheckinUpdateDto {
	
	private String seatsNo, g_id, date, t_no;

	public String getT_no() {
		return t_no;
	}

	public void setT_no(String t_no) {
		this.t_no = t_no;
	}

	public String getSeatsNo() {
		return seatsNo;
	}

	public void setSeatsNo(String seatsNo) {
		this.seatsNo = seatsNo;
	}

	public String getG_id() {
		return g_id;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
}
