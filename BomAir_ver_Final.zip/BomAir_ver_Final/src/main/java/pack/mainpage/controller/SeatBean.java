package pack.mainpage.controller;

public class SeatBean {

	private String s_no, t_no, b_name, b_pp, g_id;

	public String getG_id() {
		return g_id;
	}

	public void setG_id(String g_id) {
		this.g_id = g_id;
	}

	public String getS_no() {
		return s_no;
	}

	public void setS_no(String s_no) {
		this.s_no = s_no;
	}

	public String getT_no() {
		return t_no;
	}

	public void setT_no(String t_no) {
		this.t_no = t_no;
	}

	public String getB_name() {
		return b_name;
	}

	public void setB_name(String b_name) {
		this.b_name = b_name;
	}

	public String getB_pp() {
		return b_pp;
	}

	public void setB_pp(String b_pp) {
		this.b_pp = b_pp;
	}
	
}
